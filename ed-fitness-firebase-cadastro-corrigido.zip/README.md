# ED Fitness — front-end fiel ao layout aprovado

Projeto estático em **HTML + CSS + JavaScript** baseado na arte fornecida pelo cliente.

## Como executar

Abra `index.html` no navegador ou use uma extensão como **Live Server** no VS Code.

## Publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta para a branch `main`.
3. No GitHub, abra **Settings > Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Selecione `main` e `/ (root)`.

## Dados

`products.json` pode armazenar catálogo público simples no próprio repositório.

> GitHub/GitHub Pages **não é banco de dados transacional**. Não use JSON no GitHub para senha, clientes, pedidos, estoque em tempo real ou pagamentos. Para uma loja real, conecte o front-end a Supabase, Firebase, PostgreSQL ou outra API/backend.

## Ajustes necessários antes de produção

- Trocar o link do Instagram, caso o usuário real seja diferente de `@edfitness`.
- Trocar o número `5500000000000` no link do WhatsApp pelo telefone real com DDI + DDD.
- Integrar checkout/carrinho a um backend ou plataforma de pagamento.
- Se quiser SEO mais forte e conteúdo editável, reconstruir cada seção com assets originais do designer em vez de manter a arte aprovada como imagem-base.

## Estrutura

- `index.html`: estrutura, links e áreas clicáveis.
- `styles.css`: responsividade e posicionamento fiel à arte.
- `script.js`: carrinho local e interações.
- `products.json`: catálogo inicial.
- `assets/ed-fitness-layout.png`: layout aprovado enviado pelo cliente.
