# Firebase — ED Fitness

Projeto configurado: `ed-fitness-1398d`.

## Ativar no Firebase Console
1. Authentication > Sign-in method > habilite **Email/Password**.
2. Firestore Database > Create database > escolha uma região adequada e inicie em **Production mode**.
3. Firestore > Rules > substitua pelas regras de `firestore.rules` e publique.
4. Authentication > Settings > Authorized domains > confirme `edfitness.netlify.app` (e seu domínio próprio quando houver).

## Segurança
- Senhas são tratadas pelo Firebase Authentication e nunca gravadas no Firestore.
- Cada usuário só pode ler/escrever o próprio perfil, carrinho e criar/ler seus próprios pedidos.
- Pedidos não podem ser alterados/apagados pelo cliente após a criação.
- Não inclua Service Account/private key no frontend.
